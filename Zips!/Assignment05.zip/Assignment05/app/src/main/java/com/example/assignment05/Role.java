package com.example.assignment05;

public enum Role
{
    Student,
    Employee,
    Other
}