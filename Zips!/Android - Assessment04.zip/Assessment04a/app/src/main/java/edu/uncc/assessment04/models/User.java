package edu.uncc.assessment04.models;

import java.io.Serializable;

public class User implements Serializable {
    String name;
    String passcode;

    public User() {
    }

    public User(String name, String passcode) {
        this.name = name;
        this.passcode = passcode;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPasscode() {
        return passcode;
    }

    public void setPasscode(String passcode) {
        this.passcode = passcode;
    }

    @Override
    public String toString() {
        return name;
    }
}
