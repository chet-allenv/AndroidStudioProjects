package com.example.assignment_one;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{

    final String TAG = "Assignment 1";

    EditText editTextTempurature;

    TextView textViewConversion;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        Log.d("My Activity", "Hello");

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        editTextTempurature = findViewById(R.id.editNumber);
        textViewConversion = findViewById(R.id.conversionText);

        findViewById(R.id.button1).setOnClickListener(this);
        findViewById(R.id.button2).setOnClickListener(this);
        findViewById(R.id.button3).setOnClickListener(this);


    }

    @Override
    public void onClick(View v)
    {
        if (v.getId() == R.id.button1)
        {
            double temperature = 0;

            try {

                var entered = editTextTempurature.getText().toString();
                temperature = Double.parseDouble(entered);

                temperature = (temperature * ((double) 9/5)) + 32;

            } catch (NumberFormatException exception){

                Log.d(TAG, "Error: Invalid Number");
                Toast.makeText(this, "Error: Invalid Number", Toast.LENGTH_SHORT).show();
            }
            textViewConversion.setText(String.format("Conversion: %.2f", temperature));
        }
        else if (v.getId() == R.id.button2)
        {
            Log.d(TAG, "Pressed F to C");

            double temperature = 0;

            try {

                var entered = editTextTempurature.getText().toString();
                temperature = Double.parseDouble(entered);

                temperature = (temperature - 32) * ((double) 5 /9);

            } catch (NumberFormatException exception){

                Log.d(TAG, "Error: Invalid Number");
                Toast.makeText(this, "Error: Invalid Number", Toast.LENGTH_SHORT).show();
            }
            textViewConversion.setText(String.format("Conversion: %.2f", temperature));
        }
        else if (v.getId() == R.id.button3)
        {
            Log.d(TAG, "Pressed RESET");

            editTextTempurature.clearComposingText();
            textViewConversion.setText("Conversion: ");
        }
    }






}