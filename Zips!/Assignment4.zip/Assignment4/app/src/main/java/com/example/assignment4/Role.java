package com.example.assignment4;

public enum Role
{
    Student,
    Employee,
    Other
}